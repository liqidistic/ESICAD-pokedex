<!-- 
    Ce fichier permet d'afficher un footer et de fermer les balises body et HTML de la page
-->
</main>
</div>
<footer>
    <p>Tous droits réservés, ESICAD BTS SIO 1ere année, Développement Web 2023-2024</p>
</footer>
</body>

</html>