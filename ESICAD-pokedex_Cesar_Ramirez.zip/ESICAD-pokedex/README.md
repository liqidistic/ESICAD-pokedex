# ESICAD Pokédex

Ce projet est le squelette du TP2 de développement Web du BTS SIO 1ere année de l'ESICAD.

Vous pouvez [forker](https://docs.github.com/fr/pull-requests/collaborating-with-pull-requests/working-with-forks/fork-a-repo) ce dépôt Git pour en créer une copie sur votre compte GitHub personnel, et créer ainsi votre version du projet.

La page principale est `index.php`, elle va charger les différentes parties du site dans des fichiers PHP séparés à l'aide de l'instruction [`require_once()`](https://www.php.net/manual/fr/function.require-once.php).

Suivez les instructions du TP pour implémenter les différentes fonctionnalités du site web.
